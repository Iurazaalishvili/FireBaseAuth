package ge.msda.firebaseauth;

import android.app.Activity;

public class registration_Activity extends Activity {
}
